
-- users_profile table
CREATE TABLE public.users_profile (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  face_type TEXT CHECK (face_type IN ('oval','round','square','heart','oblong')),
  onboarding_complete BOOLEAN NOT NULL DEFAULT false,
  streak_days INTEGER NOT NULL DEFAULT 0,
  total_sessions INTEGER NOT NULL DEFAULT 0,
  display_name TEXT,
  avatar_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.users_profile TO authenticated;
GRANT ALL ON public.users_profile TO service_role;

ALTER TABLE public.users_profile ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Profile owner can select" ON public.users_profile FOR SELECT TO authenticated USING (auth.uid() = id);
CREATE POLICY "Profile owner can insert" ON public.users_profile FOR INSERT TO authenticated WITH CHECK (auth.uid() = id);
CREATE POLICY "Profile owner can update" ON public.users_profile FOR UPDATE TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);
CREATE POLICY "Profile owner can delete" ON public.users_profile FOR DELETE TO authenticated USING (auth.uid() = id);

-- exercise_sessions table
CREATE TABLE public.exercise_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.users_profile(id) ON DELETE CASCADE,
  exercise_id TEXT NOT NULL,
  duration_seconds INTEGER NOT NULL DEFAULT 0,
  completion_score DOUBLE PRECISION CHECK (completion_score >= 0 AND completion_score <= 1),
  feedback_log JSONB NOT NULL DEFAULT '{}'::jsonb,
  completed_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX exercise_sessions_user_completed_idx ON public.exercise_sessions (user_id, completed_at DESC);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.exercise_sessions TO authenticated;
GRANT ALL ON public.exercise_sessions TO service_role;

ALTER TABLE public.exercise_sessions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Session owner can select" ON public.exercise_sessions FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Session owner can insert" ON public.exercise_sessions FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Session owner can update" ON public.exercise_sessions FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Session owner can delete" ON public.exercise_sessions FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- Auto-create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.users_profile (id, display_name, avatar_url)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.raw_user_meta_data->>'name', split_part(NEW.email, '@', 1)),
    NEW.raw_user_meta_data->>'avatar_url'
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
