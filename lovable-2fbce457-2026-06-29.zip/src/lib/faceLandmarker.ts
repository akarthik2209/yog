import { FaceLandmarker, FilesetResolver } from "@mediapipe/tasks-vision";

let instancePromise: Promise<FaceLandmarker> | null = null;

export async function initFaceLandmarker(): Promise<FaceLandmarker> {
  if (instancePromise) return instancePromise;
  instancePromise = (async () => {
    const vision = await FilesetResolver.forVisionTasks(
      "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision/wasm",
    );
    return FaceLandmarker.createFromOptions(vision, {
      baseOptions: {
        modelAssetPath:
          "https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task",
        delegate: "GPU",
      },
      outputFaceBlendshapes: true,
      runningMode: "VIDEO",
      numFaces: 1,
    });
  })();
  return instancePromise;
}

/** Key landmark indices used by FaceFlow exercises. */
export const LANDMARKS = {
  upperInnerLip: 13,
  lowerInnerLip: 14,
  leftJaw: 132,
  rightJaw: 361,
  leftCheek: 234,
  rightCheek: 454,
  foreheadTop: 10,
  chin: 152,
  leftEyeTop: 159,
  leftEyeBottom: 145,
  rightEyeTop: 386,
  rightEyeBottom: 374,
  leftCheekPuffA: 116,
  leftCheekPuffB: 123,
  rightCheekPuffA: 345,
  rightCheekPuffB: 352,
} as const;

export interface Pt {
  x: number;
  y: number;
  z?: number;
}

export function dist(a: Pt, b: Pt): number {
  const dx = a.x - b.x;
  const dy = a.y - b.y;
  return Math.sqrt(dx * dx + dy * dy);
}