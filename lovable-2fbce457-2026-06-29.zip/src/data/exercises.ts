export type TargetArea =
  | "cheeks"
  | "jaw"
  | "forehead"
  | "eyes"
  | "neck"
  | "lips";

export type Difficulty = "beginner" | "intermediate" | "advanced";

export type CompletionMetricType = "distance" | "ratio" | "hold";

export interface Exercise {
  id: string;
  name: string;
  targetArea: TargetArea;
  duration: number;
  difficulty: Difficulty;
  instructions: string[];
  landmarks: {
    primary: number[];
    secondary: number[];
  };
  completionMetric: {
    type: CompletionMetricType;
    description: string;
  };
  thumbnailEmoji: string;
}

export const exercises: Exercise[] = [
  {
    id: "lions-roar",
    name: "Lion's Roar",
    targetArea: "jaw",
    duration: 30,
    difficulty: "beginner",
    instructions: [
      "Sit tall and inhale through the nose.",
      "Open your mouth as wide as possible.",
      "Stick your tongue out and down toward the chin.",
      "Exhale audibly and hold the expression.",
      "Relax and repeat in short bursts.",
    ],
    landmarks: {
      primary: [13, 14, 78, 308],
      secondary: [152, 200],
    },
    completionMetric: {
      type: "distance",
      description: "Vertical distance between upper and lower lip landmarks.",
    },
    thumbnailEmoji: "🦁",
  },
  {
    id: "fish-face",
    name: "Fish Face",
    targetArea: "cheeks",
    duration: 20,
    difficulty: "beginner",
    instructions: [
      "Suck your cheeks inward between your teeth.",
      "Pucker your lips into a small 'o'.",
      "Try to smile while holding the suction.",
      "Hold, then release slowly.",
    ],
    landmarks: {
      primary: [50, 280, 78, 308],
      secondary: [205, 425],
    },
    completionMetric: {
      type: "ratio",
      description: "Cheek width ratio relative to neutral baseline.",
    },
    thumbnailEmoji: "🐟",
  },
  {
    id: "brow-lift",
    name: "Brow Lift",
    targetArea: "forehead",
    duration: 40,
    difficulty: "intermediate",
    instructions: [
      "Place two fingers lightly above each brow.",
      "Raise your eyebrows as high as possible.",
      "Press gently downward with the fingers for resistance.",
      "Hold, breathing slowly.",
    ],
    landmarks: {
      primary: [70, 63, 105, 300, 293, 334],
      secondary: [10, 151],
    },
    completionMetric: {
      type: "hold",
      description: "Sustained brow elevation above baseline for target duration.",
    },
    thumbnailEmoji: "🤨",
  },
  {
    id: "eye-squeeze",
    name: "Eye Squeeze",
    targetArea: "eyes",
    duration: 30,
    difficulty: "beginner",
    instructions: [
      "Soften your forehead.",
      "Squeeze your right eye shut while keeping the left open.",
      "Release and switch sides.",
      "Alternate at a steady rhythm.",
    ],
    landmarks: {
      primary: [159, 145, 386, 374],
      secondary: [33, 133, 263, 362],
    },
    completionMetric: {
      type: "ratio",
      description: "Eye aspect ratio drop on the squinting side.",
    },
    thumbnailEmoji: "😉",
  },
  {
    id: "jaw-release",
    name: "Jaw Release",
    targetArea: "jaw",
    duration: 45,
    difficulty: "intermediate",
    instructions: [
      "Drop your jaw and relax your tongue.",
      "Slowly circle the jaw clockwise.",
      "Reverse direction halfway through.",
      "Keep shoulders soft and breath even.",
    ],
    landmarks: {
      primary: [152, 175, 199],
      secondary: [132, 361],
    },
    completionMetric: {
      type: "distance",
      description: "Chin landmark trajectory length over time.",
    },
    thumbnailEmoji: "🌀",
  },
  {
    id: "cheek-puff",
    name: "Cheek Puff",
    targetArea: "cheeks",
    duration: 25,
    difficulty: "beginner",
    instructions: [
      "Take a deep breath and seal your lips.",
      "Push the air into your right cheek and hold.",
      "Transfer the air to the left cheek and hold.",
      "Continue alternating without losing air.",
    ],
    landmarks: {
      primary: [205, 425],
      secondary: [50, 280],
    },
    completionMetric: {
      type: "ratio",
      description: "Asymmetry between left and right cheek expansion.",
    },
    thumbnailEmoji: "💨",
  },
  {
    id: "neck-stretch",
    name: "Neck Stretch",
    targetArea: "neck",
    duration: 60,
    difficulty: "advanced",
    instructions: [
      "Sit tall with shoulders down.",
      "Tilt your head gently to the right, place hand on temple.",
      "Press lightly into the hand for resistance, then release.",
      "Repeat on the left, then forward and back.",
    ],
    landmarks: {
      primary: [10, 152],
      secondary: [234, 454],
    },
    completionMetric: {
      type: "hold",
      description: "Sustained head tilt angle within target range.",
    },
    thumbnailEmoji: "🧘",
  },
  {
    id: "lip-purse",
    name: "Lip Purse",
    targetArea: "lips",
    duration: 20,
    difficulty: "beginner",
    instructions: [
      "Bring your lips together into a tight pucker.",
      "Push them forward as far as comfortable.",
      "Hold the pose, feeling the muscles around the mouth engage.",
      "Release slowly.",
    ],
    landmarks: {
      primary: [78, 308, 13, 14],
      secondary: [61, 291],
    },
    completionMetric: {
      type: "distance",
      description: "Horizontal lip corner compression vs baseline.",
    },
    thumbnailEmoji: "💋",
  },
];

export const targetAreas: TargetArea[] = [
  "cheeks",
  "jaw",
  "forehead",
  "eyes",
  "neck",
  "lips",
];

const faceTypeFocus: Record<string, TargetArea[]> = {
  oval: ["cheeks", "jaw", "neck"],
  round: ["jaw", "cheeks", "neck"],
  square: ["cheeks", "lips", "forehead"],
  heart: ["jaw", "lips", "neck"],
  oblong: ["cheeks", "forehead", "lips"],
};

export function getRecommendedExercises(
  faceType: string | null | undefined,
  count = 3,
): Exercise[] {
  const focus = faceType ? faceTypeFocus[faceType] : null;
  if (focus) {
    const picks: Exercise[] = [];
    for (const area of focus) {
      const match = exercises.find(
        (e) => e.targetArea === area && !picks.includes(e),
      );
      if (match) picks.push(match);
      if (picks.length >= count) break;
    }
    if (picks.length >= count) return picks.slice(0, count);
  }
  const shuffled = [...exercises].sort(() => Math.random() - 0.5);
  return shuffled.slice(0, count);
}