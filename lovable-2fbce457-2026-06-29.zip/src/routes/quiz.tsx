import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight } from "lucide-react";

export const Route = createFileRoute("/quiz")({
  head: () => ({
    meta: [
      { title: "Face type quiz — FaceFlow" },
      { name: "description", content: "Discover your face type and get a tailored ritual." },
    ],
  }),
  component: Quiz,
});

const steps = [
  {
    q: "Where do you hold the most tension?",
    options: ["Jaw & temples", "Brow & forehead", "Cheeks & under-eyes", "Neck & shoulders"],
  },
  {
    q: "What's your skin's natural tendency?",
    options: ["Dry", "Combination", "Oily", "Sensitive"],
  },
  {
    q: "How would you describe your face shape?",
    options: ["Oval", "Round", "Heart", "Square"],
  },
  {
    q: "What outcome matters most to you?",
    options: ["Lift & tone", "Smoother lines", "Brighter glow", "Stress release"],
  },
  {
    q: "How often can you practice?",
    options: ["A few minutes daily", "3× a week", "Weekends only", "Whenever I remember"],
  },
  {
    q: "What time of day works best?",
    options: ["Early morning", "Midday reset", "Evening wind-down", "Right before bed"],
  },
];

function Quiz() {
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const total = steps.length;
  const current = steps[step];
  const progress = ((step + 1) / total) * 100;

  return (
    <div className="mx-auto flex min-h-screen max-w-3xl flex-col px-6 py-12">
      <header className="flex items-center justify-between text-xs uppercase tracking-widest text-muted-foreground">
        <span>Face type quiz</span>
        <span>
          {step + 1} / {total}
        </span>
      </header>

      <div className="mt-4 h-1 overflow-hidden rounded-full bg-secondary">
        <div
          className="h-full rounded-full bg-accent transition-all duration-500"
          style={{ width: `${progress}%` }}
        />
      </div>

      <div className="mt-16 flex flex-1 flex-col">
        <h1 className="max-w-xl text-4xl leading-tight">{current.q}</h1>

        <div className="mt-10 grid gap-3 sm:grid-cols-2">
          {current.options.map((opt) => {
            const selected = answers[step] === opt;
            return (
              <button
                key={opt}
                onClick={() => setAnswers({ ...answers, [step]: opt })}
                className={
                  "rounded-2xl border bg-card px-6 py-5 text-left text-base transition " +
                  (selected
                    ? "border-accent bg-accent/10"
                    : "border-transparent shadow-sm hover:border-accent/40")
                }
              >
                {opt}
              </button>
            );
          })}
        </div>
      </div>

      <nav className="mt-12 flex items-center justify-between">
        <button
          onClick={() => setStep(Math.max(0, step - 1))}
          disabled={step === 0}
          className="inline-flex items-center gap-2 text-sm text-muted-foreground disabled:opacity-30"
        >
          <ArrowLeft className="h-4 w-4" /> Back
        </button>

        <button
          onClick={() => setStep(Math.min(total - 1, step + 1))}
          className="inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 text-sm text-primary-foreground hover:opacity-90"
        >
          {step === total - 1 ? "See your ritual" : "Continue"}
          <ArrowRight className="h-4 w-4" />
        </button>
      </nav>
    </div>
  );
}