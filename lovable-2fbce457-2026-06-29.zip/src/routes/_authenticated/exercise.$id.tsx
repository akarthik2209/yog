import { createFileRoute, useNavigate, notFound } from "@tanstack/react-router";
import { useEffect, useRef, useState, useCallback } from "react";
import { Camera, Pause, Play, RotateCcw, X, CheckCircle2 } from "lucide-react";
import { exercises, type Exercise } from "@/data/exercises";
import { initFaceLandmarker } from "@/lib/faceLandmarker";
import type { FaceLandmarker } from "@mediapipe/tasks-vision";

export const Route = createFileRoute("/_authenticated/exercise/$id")({
  loader: ({ params }) => {
    const exercise = exercises.find((e) => e.id === params.id);
    if (!exercise) throw notFound();
    return { exercise };
  },
  head: ({ loaderData }) => ({
    meta: [
      { title: `${loaderData?.exercise.name ?? "Exercise"} — FaceFlow` },
      { name: "description", content: "Guided face yoga session with live webcam." },
    ],
  }),
  errorComponent: ({ error, reset }) => (
    <div className="grid min-h-screen place-items-center bg-charcoal text-cream">
      <div className="text-center">
        <p>Couldn't load this exercise.</p>
        <p className="mt-1 text-sm text-cream/60">{error.message}</p>
        <button onClick={reset} className="mt-4 rounded-full bg-blush px-4 py-2 text-charcoal">
          Try again
        </button>
      </div>
    </div>
  ),
  notFoundComponent: () => (
    <div className="grid min-h-screen place-items-center bg-charcoal text-cream">
      <p>Exercise not found.</p>
    </div>
  ),
  component: ExercisePlayer,
});

type Phase = "idle" | "permission-denied" | "countdown" | "running" | "paused" | "done";

function ExercisePlayer() {
  const { exercise } = Route.useLoaderData();
  const navigate = useNavigate();

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const rafRef = useRef<number | null>(null);
  const startTimeRef = useRef<number | null>(null);
  const elapsedBeforePauseRef = useRef(0);
  const landmarkerRef = useRef<FaceLandmarker | null>(null);
  const detectRafRef = useRef<number | null>(null);
  const lastVideoTimeRef = useRef<number>(-1);

  const [phase, setPhase] = useState<Phase>("idle");
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [countdown, setCountdown] = useState(3);
  const [elapsed, setElapsed] = useState(0);

  const stopStream = useCallback(() => {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    if (videoRef.current) videoRef.current.srcObject = null;
  }, []);

  const requestCamera = useCallback(async () => {
    setCameraError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "user", width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false,
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play().catch(() => {});
      }
      return true;
    } catch (err) {
      const e = err as DOMException;
      let msg = "We couldn't access your camera.";
      if (e.name === "NotAllowedError") msg = "Camera access was blocked. Allow camera permissions in your browser to start.";
      else if (e.name === "NotFoundError") msg = "No camera was found on this device.";
      else if (e.name === "NotReadableError") msg = "Your camera is in use by another application.";
      setCameraError(msg);
      setPhase("permission-denied");
      return false;
    }
  }, []);

  // Initial camera + canvas sizing
  useEffect(() => {
    let mounted = true;
    (async () => {
      const ok = await requestCamera();
      if (!ok || !mounted) return;
      try {
        landmarkerRef.current = await initFaceLandmarker();
      } catch (e) {
        console.error("Failed to init FaceLandmarker", e);
      }
      if (!mounted) return;
      setPhase("countdown");
      setCountdown(3);
    })();
    return () => {
      mounted = false;
      stopStream();
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
      if (detectRafRef.current) cancelAnimationFrame(detectRafRef.current);
    };
  }, [requestCamera, stopStream]);

  // Resize canvas to match video
  useEffect(() => {
    const v = videoRef.current;
    const c = canvasRef.current;
    if (!v || !c) return;
    const sync = () => {
      c.width = v.videoWidth || c.clientWidth;
      c.height = v.videoHeight || c.clientHeight;
    };
    v.addEventListener("loadedmetadata", sync);
    return () => v.removeEventListener("loadedmetadata", sync);
  }, [phase]);

  // Face detection loop — runs whenever the video is streaming
  useEffect(() => {
    if (phase === "idle" || phase === "permission-denied" || phase === "done") return;
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas) return;

    const primary = new Set<number>(exercise.landmarks.primary);

    const loop = () => {
      const lm = landmarkerRef.current;
      const ctx = canvas.getContext("2d");
      if (!lm || !ctx || video.readyState < 2) {
        detectRafRef.current = requestAnimationFrame(loop);
        return;
      }
      if (canvas.width !== video.videoWidth || canvas.height !== video.videoHeight) {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
      }
      const now = performance.now();
      if (video.currentTime !== lastVideoTimeRef.current) {
        lastVideoTimeRef.current = video.currentTime;
        try {
          const result = lm.detectForVideo(video, now);
          ctx.clearRect(0, 0, canvas.width, canvas.height);
          const faces = result.faceLandmarks;
          if (faces && faces.length > 0) {
            const pts = faces[0];
            ctx.fillStyle = "#7CFFB2";
            primary.forEach((idx: number) => {
              const p = pts[idx];
              if (!p) return;
              ctx.beginPath();
              ctx.arc(p.x * canvas.width, p.y * canvas.height, 4, 0, Math.PI * 2);
              ctx.fill();
            });
            // Debug logging — throttled by detection cadence
            console.debug("[FaceFlow] landmarks", {
              exercise: exercise.id,
              primary: exercise.landmarks.primary.map((i: number) => pts[i]),
              blendshapes: result.faceBlendshapes?.[0]?.categories
                ?.slice(0, 5)
                .map((c) => ({ name: c.categoryName, score: c.score })),
            });
          }
        } catch (e) {
          console.error("detectForVideo failed", e);
        }
      }
      detectRafRef.current = requestAnimationFrame(loop);
    };
    detectRafRef.current = requestAnimationFrame(loop);
    return () => {
      if (detectRafRef.current) cancelAnimationFrame(detectRafRef.current);
    };
  }, [phase, exercise.id, exercise.landmarks.primary]);

  // Countdown
  useEffect(() => {
    if (phase !== "countdown") return;
    if (countdown <= 0) {
      startTimeRef.current = performance.now();
      elapsedBeforePauseRef.current = 0;
      setElapsed(0);
      setPhase("running");
      return;
    }
    const t = setTimeout(() => setCountdown((n) => n - 1), 1000);
    return () => clearTimeout(t);
  }, [phase, countdown]);

  // Timer loop
  useEffect(() => {
    if (phase !== "running") return;
    const tick = () => {
      const start = startTimeRef.current ?? performance.now();
      const e = elapsedBeforePauseRef.current + (performance.now() - start) / 1000;
      setElapsed(e);
      if (e >= exercise.duration) {
        setElapsed(exercise.duration);
        setPhase("done");
        return;
      }
      rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, [phase, exercise.duration]);

  const handlePause = () => {
    if (phase !== "running") return;
    const start = startTimeRef.current ?? performance.now();
    elapsedBeforePauseRef.current += (performance.now() - start) / 1000;
    setPhase("paused");
  };
  const handleResume = () => {
    startTimeRef.current = performance.now();
    setPhase("running");
  };
  const handleRestart = () => {
    elapsedBeforePauseRef.current = 0;
    setElapsed(0);
    setCountdown(3);
    setPhase("countdown");
  };
  const handleExit = () => {
    stopStream();
    navigate({ to: "/dashboard" });
  };
  const handleSave = () => {
    // Persistence wired in a later step.
    stopStream();
    navigate({ to: "/dashboard" });
  };

  const progress = Math.min(1, elapsed / exercise.duration);
  const remaining = Math.max(0, exercise.duration - elapsed);

  return (
    <div className="flex h-screen flex-col bg-charcoal text-cream">
      {/* Progress bar */}
      <div className="h-1 w-full bg-cream/10">
        <div
          className="h-full bg-blush transition-[width] duration-100 ease-linear"
          style={{ width: `${progress * 100}%` }}
        />
      </div>

      <div className="flex items-center justify-between px-8 py-5">
        <div>
          <p className="text-xs uppercase tracking-widest text-cream/60">Now practicing</p>
          <h1 className="mt-1 text-2xl text-cream">{exercise.name}</h1>
        </div>
        <div className="flex items-center gap-6">
          <div className="text-right">
            <p className="text-xs uppercase tracking-widest text-cream/50">Remaining</p>
            <p className="font-serif text-xl tabular-nums">{formatTime(remaining)}</p>
          </div>
          <button
            onClick={handleExit}
            aria-label="Exit session"
            className="grid h-9 w-9 place-items-center rounded-full bg-white/5 text-cream/70 hover:bg-white/10"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      </div>

      <div className="grid flex-1 gap-6 px-8 pb-8 lg:grid-cols-[1.6fr_1fr]">
        {/* Webcam panel */}
        <div className="relative flex flex-col overflow-hidden rounded-2xl bg-black/40">
          <div className="relative flex-1 overflow-hidden">
            <video
              ref={videoRef}
              playsInline
              muted
              autoPlay
              className="absolute inset-0 h-full w-full object-cover"
              style={{ transform: "scaleX(-1)" }}
            />
            <canvas
              ref={canvasRef}
              className="pointer-events-none absolute inset-0 h-full w-full"
              style={{ transform: "scaleX(-1)" }}
            />

            {phase === "permission-denied" && (
              <PermissionDeniedOverlay
                message={cameraError ?? "Camera unavailable."}
                onRetry={async () => {
                  const ok = await requestCamera();
                  if (ok) {
                    setPhase("countdown");
                    setCountdown(3);
                  }
                }}
              />
            )}

            {phase === "countdown" && (
              <div className="absolute inset-0 grid place-items-center bg-charcoal/40 backdrop-blur-sm">
                <div className="text-center">
                  <p className="text-xs uppercase tracking-widest text-cream/70">Get ready</p>
                  <p className="mt-3 font-serif text-9xl text-cream">
                    {countdown === 0 ? "Go" : countdown}
                  </p>
                </div>
              </div>
            )}

            {phase === "paused" && (
              <div className="absolute inset-0 grid place-items-center bg-charcoal/60">
                <p className="font-serif text-3xl">Paused</p>
              </div>
            )}

            {phase === "done" && (
              <ResultsOverlay
                exercise={exercise}
                onSave={handleSave}
                onRestart={handleRestart}
              />
            )}

            {phase === "idle" && (
              <div className="absolute inset-0 grid place-items-center text-cream/50">
                <div className="flex flex-col items-center gap-3">
                  <Camera className="h-10 w-10" />
                  <p className="text-sm">Starting camera…</p>
                </div>
              </div>
            )}
          </div>

          <div className="flex items-center justify-center gap-3 border-t border-white/5 bg-black/30 px-6 py-4">
            <ControlButton onClick={handleRestart} disabled={phase === "idle" || phase === "permission-denied"} label="Restart">
              <RotateCcw className="h-4 w-4" />
            </ControlButton>
            <button
              onClick={phase === "running" ? handlePause : phase === "paused" ? handleResume : undefined}
              disabled={phase !== "running" && phase !== "paused"}
              className="grid h-14 w-14 place-items-center rounded-full bg-blush text-charcoal transition hover:opacity-90 disabled:opacity-40"
              aria-label={phase === "running" ? "Pause" : "Resume"}
            >
              {phase === "running" ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
            </button>
            <ControlButton onClick={handleExit} label="Exit">
              <X className="h-4 w-4" />
            </ControlButton>
          </div>
        </div>

        {/* Instructions panel */}
        <aside className="flex flex-col rounded-2xl bg-cream/5 p-8">
          <p className="text-xs uppercase tracking-widest text-cream/60 capitalize">
            {exercise.targetArea} · {exercise.difficulty}
          </p>
          <h2 className="mt-2 text-cream">{exercise.name}</h2>

          <div className="my-6 h-px bg-white/10" />

          <ol className="space-y-3">
            {exercise.instructions.map((step: string, i: number) => (
              <li key={i} className="flex gap-3 text-sm text-cream/75">
                <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-cream/10 text-xs">
                  {i + 1}
                </span>
                <span className="leading-relaxed">{step}</span>
              </li>
            ))}
          </ol>

          <div className="mt-auto pt-8">
            <div className="h-1 overflow-hidden rounded-full bg-cream/10">
              <div
                className="h-full rounded-full bg-blush transition-[width] duration-100 ease-linear"
                style={{ width: `${progress * 100}%` }}
              />
            </div>
            <div className="mt-2 flex justify-between text-xs text-cream/50 tabular-nums">
              <span>{formatTime(elapsed)}</span>
              <span>{formatTime(exercise.duration)}</span>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}

function ControlButton({
  children,
  onClick,
  disabled,
  label,
}: {
  children: React.ReactNode;
  onClick?: () => void;
  disabled?: boolean;
  label: string;
}) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      aria-label={label}
      className="grid h-10 w-10 place-items-center rounded-full bg-white/5 text-cream/80 transition hover:bg-white/10 disabled:opacity-40"
    >
      {children}
    </button>
  );
}

function PermissionDeniedOverlay({ message, onRetry }: { message: string; onRetry: () => void }) {
  return (
    <div className="absolute inset-0 grid place-items-center bg-charcoal/80 px-6 backdrop-blur-sm">
      <div className="max-w-md text-center">
        <div className="mx-auto grid h-12 w-12 place-items-center rounded-full bg-blush/20 text-blush">
          <Camera className="h-5 w-5" />
        </div>
        <h3 className="mt-4 font-serif text-2xl text-cream">Camera needed</h3>
        <p className="mt-2 text-sm leading-relaxed text-cream/70">{message}</p>
        <p className="mt-3 text-xs text-cream/50">
          Click the camera icon in your browser's address bar, allow access, then try again.
        </p>
        <button
          onClick={onRetry}
          className="mt-6 rounded-full bg-blush px-5 py-2.5 text-sm font-medium text-charcoal hover:opacity-90"
        >
          Try again
        </button>
      </div>
    </div>
  );
}

function ResultsOverlay({
  exercise,
  onSave,
  onRestart,
}: {
  exercise: Exercise;
  onSave: () => void;
  onRestart: () => void;
}) {
  return (
    <div className="absolute inset-0 grid place-items-center bg-charcoal/80 px-6 backdrop-blur-sm">
      <div className="max-w-md text-center">
        <div className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-blush/20 text-blush">
          <CheckCircle2 className="h-7 w-7" />
        </div>
        <h3 className="mt-4 font-serif text-3xl text-cream">Great work!</h3>
        <p className="mt-2 text-sm text-cream/70">
          You completed {exercise.name} · {formatTime(exercise.duration)}
        </p>
        <div className="mt-6 flex justify-center gap-3">
          <button
            onClick={onRestart}
            className="rounded-full bg-white/10 px-5 py-2.5 text-sm text-cream hover:bg-white/15"
          >
            Repeat
          </button>
          <button
            onClick={onSave}
            className="rounded-full bg-blush px-5 py-2.5 text-sm font-medium text-charcoal hover:opacity-90"
          >
            Save & Continue
          </button>
        </div>
      </div>
    </div>
  );
}

function formatTime(seconds: number) {
  const total = Math.max(0, Math.ceil(seconds));
  const m = Math.floor(total / 60);
  const s = total % 60;
  return `${m}:${s.toString().padStart(2, "0")}`;
}