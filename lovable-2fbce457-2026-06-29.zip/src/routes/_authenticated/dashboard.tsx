import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Play, Clock, Flame } from "lucide-react";
import { SidebarLayout } from "@/components/SidebarLayout";
import { useProfile } from "@/hooks/use-auth";
import {
  exercises,
  getRecommendedExercises,
  targetAreas,
  type Exercise,
  type TargetArea,
} from "@/data/exercises";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({
    meta: [
      { title: "Dashboard — FaceFlow" },
      { name: "description", content: "Your daily face yoga practice at a glance." },
    ],
  }),
  component: Dashboard,
});

function Dashboard() {
  const { user } = Route.useRouteContext();
  const { data: profile } = useProfile(user.id);
  const name =
    profile?.display_name ||
    user.user_metadata?.full_name ||
    user.email?.split("@")[0] ||
    "there";

  const recommended = useMemo(
    () => getRecommendedExercises(profile?.face_type, 3),
    [profile?.face_type],
  );
  const [filter, setFilter] = useState<TargetArea | "all">("all");
  const filtered = filter === "all" ? exercises : exercises.filter((e) => e.targetArea === filter);

  return (
    <SidebarLayout>
      <div className="mx-auto max-w-6xl px-8 py-12">
        <header className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <p className="text-sm text-muted-foreground">Welcome back</p>
            <h1 className="mt-1 text-4xl">Good to see you, {name}.</h1>
            <p className="mt-3 max-w-md text-muted-foreground">
              A short ritual today keeps your facial muscles toned and your skin glowing.
            </p>
          </div>
          <div className="flex items-center gap-6 rounded-2xl bg-card px-6 py-4 shadow-sm">
            <Stat icon={<Flame className="h-4 w-4" />} label="Streak" value={`${profile?.streak_days ?? 0}d`} />
            <Stat icon={<Clock className="h-4 w-4" />} label="Sessions" value={`${profile?.total_sessions ?? 0}`} />
          </div>
        </header>

        <section className="mt-12">
          <div className="flex items-baseline justify-between">
            <h2 className="text-2xl">Today's recommended routine</h2>
            <span className="text-sm text-muted-foreground">
              {profile?.face_type ? `Tuned for ${profile.face_type} faces` : "A balanced starter set"}
            </span>
          </div>
          <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {recommended.map((e) => (
              <ExerciseCard key={e.id} exercise={e} highlight />
            ))}
          </div>
        </section>

        <section className="mt-16">
          <div className="flex flex-wrap items-baseline justify-between gap-3">
            <h2 className="text-2xl">Exercise library</h2>
            <span className="text-sm text-muted-foreground">{filtered.length} exercises</span>
          </div>

          <div className="mt-5 flex flex-wrap gap-2">
            <FilterChip active={filter === "all"} onClick={() => setFilter("all")}>
              All
            </FilterChip>
            {targetAreas.map((area) => (
              <FilterChip key={area} active={filter === area} onClick={() => setFilter(area)}>
                {area}
              </FilterChip>
            ))}
          </div>

          <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {filtered.map((e) => (
              <ExerciseCard key={e.id} exercise={e} />
            ))}
          </div>
        </section>
      </div>
    </SidebarLayout>
  );
}

function ExerciseCard({ exercise, highlight }: { exercise: Exercise; highlight?: boolean }) {
  const minutes = exercise.duration >= 60
    ? `${Math.round(exercise.duration / 60)} min`
    : `${exercise.duration}s`;
  return (
    <article
      className={
        "group flex flex-col rounded-2xl bg-card p-6 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md " +
        (highlight ? "ring-1 ring-accent/40" : "")
      }
    >
      <div className="flex h-32 items-center justify-center rounded-xl bg-accent/20 text-5xl">
        <span aria-hidden>{exercise.thumbnailEmoji}</span>
      </div>
      <div className="mt-5 flex items-start justify-between gap-3">
        <h3 className="text-lg leading-snug">{exercise.name}</h3>
        <span className="shrink-0 rounded-full bg-secondary px-2.5 py-1 text-xs text-muted-foreground">
          {minutes}
        </span>
      </div>
      <p className="mt-2 text-sm capitalize text-muted-foreground">
        {exercise.targetArea}
      </p>
      <div className="mt-4 flex items-center justify-between">
        <DifficultyBadge difficulty={exercise.difficulty} />
        <Link
          to="/exercise/$id"
          params={{ id: exercise.id }}
          className="inline-flex items-center gap-1.5 rounded-full bg-foreground px-4 py-1.5 text-xs font-medium text-background transition hover:opacity-90"
        >
          <Play className="h-3 w-3" /> Start
        </Link>
      </div>
    </article>
  );
}

function DifficultyBadge({ difficulty }: { difficulty: Exercise["difficulty"] }) {
  const tone =
    difficulty === "beginner"
      ? "bg-emerald-100 text-emerald-900"
      : difficulty === "intermediate"
        ? "bg-amber-100 text-amber-900"
        : "bg-rose-100 text-rose-900";
  return (
    <span className={"rounded-full px-2.5 py-1 text-[10px] uppercase tracking-wider " + tone}>
      {difficulty}
    </span>
  );
}

function FilterChip({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      className={
        "rounded-full px-4 py-1.5 text-xs capitalize transition " +
        (active
          ? "bg-foreground text-background"
          : "bg-secondary text-muted-foreground hover:text-foreground")
      }
    >
      {children}
    </button>
  );
}

function Stat({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="flex items-center gap-3">
      <span className="grid h-8 w-8 place-items-center rounded-full bg-accent/30 text-foreground">
        {icon}
      </span>
      <div>
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className="font-serif text-lg leading-none">{value}</p>
      </div>
    </div>
  );
}