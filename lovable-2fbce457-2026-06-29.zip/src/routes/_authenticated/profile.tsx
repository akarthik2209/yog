import { createFileRoute } from "@tanstack/react-router";
import { Flame, Clock, Trophy, Calendar } from "lucide-react";
import { SidebarLayout } from "@/components/SidebarLayout";
import { useProfile } from "@/hooks/use-auth";

export const Route = createFileRoute("/_authenticated/profile")({
  head: () => ({
    meta: [
      { title: "Profile — FaceFlow" },
      { name: "description", content: "Your face yoga progress, streak and ritual history." },
    ],
  }),
  component: Profile,
});

function Profile() {
  const { user } = Route.useRouteContext();
  const { data: profile } = useProfile(user.id);
  const name =
    profile?.display_name ||
    user.user_metadata?.full_name ||
    user.email?.split("@")[0] ||
    "Friend";
  const initial = name.trim().charAt(0).toUpperCase();
  const days = Array.from({ length: 28 }, (_, i) => i);

  return (
    <SidebarLayout>
      <div className="mx-auto max-w-5xl px-8 py-12">
        <header className="flex flex-wrap items-center gap-6">
          {profile?.avatar_url ? (
            <img
              src={profile.avatar_url}
              alt=""
              className="h-20 w-20 rounded-full object-cover"
            />
          ) : (
            <div className="grid h-20 w-20 place-items-center rounded-full bg-accent/30 font-serif text-2xl">
              {initial}
            </div>
          )}
          <div>
            <h1 className="text-3xl">{name}</h1>
            <p className="mt-1 text-sm text-muted-foreground">
              {user.email} · {profile?.face_type ? `${profile.face_type} face ritual` : "Face type pending"}
            </p>
          </div>
        </header>

        <section className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard icon={<Flame className="h-4 w-4" />} label="Current streak" value={`${profile?.streak_days ?? 0}`} unit="days" />
          <StatCard icon={<Trophy className="h-4 w-4" />} label="Longest streak" value="0" unit="days" />
          <StatCard icon={<Clock className="h-4 w-4" />} label="Total practice" value="0" unit="hours" />
          <StatCard icon={<Calendar className="h-4 w-4" />} label="Sessions" value={`${profile?.total_sessions ?? 0}`} unit="completed" />
        </section>

        <section className="mt-10 rounded-2xl bg-card p-8 shadow-sm">
          <div className="flex items-baseline justify-between">
            <h2 className="text-2xl">Last 4 weeks</h2>
            <span className="text-xs text-muted-foreground">0 of 28 days</span>
          </div>
          <div className="mt-6 grid grid-cols-7 gap-2">
            {days.map((d) => (
              <div key={d} className="aspect-square rounded-lg bg-secondary" />
            ))}
          </div>
        </section>
      </div>
    </SidebarLayout>
  );
}

function StatCard({
  icon,
  label,
  value,
  unit,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  unit: string;
}) {
  return (
    <div className="rounded-2xl bg-card p-6 shadow-sm">
      <div className="flex items-center gap-2 text-muted-foreground">
        {icon}
        <span className="text-xs uppercase tracking-wider">{label}</span>
      </div>
      <p className="mt-4 font-serif text-4xl leading-none">{value}</p>
      <p className="mt-1 text-xs text-muted-foreground">{unit}</p>
    </div>
  );
}