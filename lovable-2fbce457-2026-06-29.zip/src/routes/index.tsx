import { createFileRoute } from "@tanstack/react-router";
import { Link } from "@tanstack/react-router";
import { Sparkles, Activity, Camera } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "FaceFlow — Face Yoga Coaching" },
      {
        name: "description",
        content:
          "Your face has 57 muscles. Train them with guided face yoga and a daily ritual that fits your morning.",
      },
      { property: "og:title", content: "FaceFlow — Face Yoga Coaching" },
      {
        property: "og:description",
        content: "Guided face yoga sessions, form coaching, and a daily ritual built for you.",
      },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-6 py-6">
        <Link to="/" className="font-serif text-2xl tracking-tight">
          FaceFlow
        </Link>
        <nav className="hidden items-center gap-8 text-sm text-muted-foreground md:flex">
          <a className="hover:text-foreground">The practice</a>
          <a className="hover:text-foreground">Science</a>
          <a className="hover:text-foreground">Stories</a>
        </nav>
        <Link
          to="/dashboard"
          className="rounded-full bg-primary px-5 py-2.5 text-sm text-primary-foreground hover:opacity-90"
        >
          Enter studio
        </Link>
      </header>

      <section className="mx-auto max-w-6xl px-6 pt-20 pb-28 md:pt-28 md:pb-36">
        <div className="grid items-center gap-16 md:grid-cols-[1.1fr_1fr]">
          <div>
            <span className="inline-flex items-center gap-2 rounded-full bg-accent/20 px-3 py-1 text-xs uppercase tracking-widest text-foreground/80">
              <span className="h-1.5 w-1.5 rounded-full bg-accent" />
              New season ritual
            </span>
            <h1 className="mt-6 text-5xl leading-[1.05] md:text-7xl">
              Your face has 57 muscles.
              <br />
              <span className="italic text-foreground/70">Let's train them.</span>
            </h1>
            <p className="mt-7 max-w-md text-lg text-muted-foreground">
              A daily face yoga ritual — guided, gentle, and tailored to your face type.
              Five minutes is all it takes.
            </p>
            <div className="mt-9 flex flex-wrap items-center gap-4">
              <Link
                to="/quiz"
                className="rounded-full bg-primary px-7 py-3.5 text-sm text-primary-foreground hover:opacity-90"
              >
                Take the face type quiz
              </Link>
              <Link to="/dashboard" className="text-sm text-muted-foreground hover:text-foreground">
                Or explore the studio →
              </Link>
            </div>
          </div>

          <div className="relative aspect-[4/5] overflow-hidden rounded-3xl bg-accent/20">
            <div className="absolute inset-0 flex items-center justify-center">
              <span className="font-serif text-[14rem] leading-none text-accent/40">F</span>
            </div>
            <div className="absolute bottom-6 left-6 right-6 rounded-2xl bg-card/90 p-5 backdrop-blur">
              <p className="text-xs uppercase tracking-widest text-muted-foreground">
                Today's session
              </p>
              <p className="mt-1 font-serif text-xl">Jawline Sculpt · 6 min</p>
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-6 pb-28">
        <div className="grid gap-5 md:grid-cols-3">
          {features.map((f) => (
            <article
              key={f.title}
              className="rounded-2xl bg-card p-8 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md"
            >
              <span className="grid h-10 w-10 place-items-center rounded-full bg-accent/30">
                {f.icon}
              </span>
              <h3 className="mt-6 text-2xl">{f.title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{f.body}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-4xl px-6 pb-32 text-center">
        <h2 className="text-4xl leading-tight md:text-5xl">
          A skincare practice you can <em>feel</em> working.
        </h2>
        <p className="mx-auto mt-5 max-w-xl text-muted-foreground">
          Join thousands of women redefining what aging looks like — confidently, calmly,
          and on their own terms.
        </p>
        <Link
          to="/quiz"
          className="mt-9 inline-flex rounded-full bg-primary px-8 py-4 text-sm text-primary-foreground hover:opacity-90"
        >
          Begin your ritual
        </Link>
      </section>

      <footer className="border-t border-border">
        <div className="mx-auto flex max-w-6xl flex-col items-start justify-between gap-3 px-6 py-8 text-xs text-muted-foreground md:flex-row md:items-center">
          <p className="font-serif text-base text-foreground">FaceFlow</p>
          <p>© {new Date().getFullYear()} FaceFlow Studio. Made with care.</p>
        </div>
      </footer>
    </div>
  );
}

const features = [
  {
    icon: <Sparkles className="h-4 w-4" />,
    title: "Personalised rituals",
    body: "A two-minute quiz maps your face type, tension patterns, and goals into a daily plan that evolves with you.",
  },
  {
    icon: <Camera className="h-4 w-4" />,
    title: "Live form coaching",
    body: "Optional webcam guidance helps you find each movement precisely — no mirror required.",
  },
  {
    icon: <Activity className="h-4 w-4" />,
    title: "Progress you can see",
    body: "Track your streak, your time, and the small shifts that add up to a more lifted, rested face.",
  },
];
