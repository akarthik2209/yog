import type { ReactNode } from "react";
import { AppSidebar } from "./AppSidebar";

export function SidebarLayout({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-screen w-full bg-background">
      <AppSidebar />
      <main className="flex-1 min-w-0">{children}</main>
    </div>
  );
}