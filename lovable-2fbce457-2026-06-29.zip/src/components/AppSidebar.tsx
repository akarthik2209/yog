import { Link, useRouterState } from "@tanstack/react-router";
import { LayoutDashboard, LogIn, LogOut, Play, Sparkles, User } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuthUser, useProfile } from "@/hooks/use-auth";

const items = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { to: "/exercise", label: "Practice", icon: Play },
  { to: "/quiz", label: "Face type quiz", icon: Sparkles },
  { to: "/profile", label: "Profile", icon: User },
] as const;

export function AppSidebar() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const user = useAuthUser();
  const { data: profile } = useProfile(user?.id);
  const displayName =
    profile?.display_name ||
    user?.user_metadata?.full_name ||
    user?.email?.split("@")[0] ||
    "";
  const initial = (displayName || "?").trim().charAt(0).toUpperCase();

  return (
    <aside className="hidden md:flex w-64 shrink-0 flex-col border-r border-sidebar-border bg-sidebar text-sidebar-foreground">
      <div className="px-6 py-8">
        <Link to="/" className="font-serif text-2xl tracking-tight">
          FaceFlow
        </Link>
        <p className="mt-1 text-xs text-muted-foreground">Daily face yoga</p>
      </div>

      <nav className="flex-1 px-3">
        <ul className="space-y-1">
          {items.map(({ to, label, icon: Icon }) => {
            const active = pathname === to;
            return (
              <li key={to}>
                <Link
                  to={to}
                  className={
                    "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-colors " +
                    (active
                      ? "bg-sidebar-accent text-sidebar-accent-foreground"
                      : "text-muted-foreground hover:bg-sidebar-accent/60 hover:text-sidebar-accent-foreground")
                  }
                >
                  <Icon className="h-4 w-4" />
                  <span>{label}</span>
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>

      <div className="m-3 rounded-2xl bg-accent/30 p-4">
        {user === undefined ? (
          <div className="h-12 animate-pulse rounded-md bg-foreground/5" />
        ) : user ? (
          <div className="flex items-center gap-3">
            {profile?.avatar_url ? (
              <img
                src={profile.avatar_url}
                alt=""
                className="h-10 w-10 rounded-full object-cover"
              />
            ) : (
              <span className="grid h-10 w-10 place-items-center rounded-full bg-background font-serif text-base">
                {initial}
              </span>
            )}
            <div className="min-w-0 flex-1">
              <p className="truncate font-serif text-sm leading-tight">{displayName}</p>
              <button
                onClick={() => supabase.auth.signOut()}
                className="mt-0.5 inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground"
              >
                <LogOut className="h-3 w-3" /> Sign out
              </button>
            </div>
          </div>
        ) : (
          <Link
            to="/auth"
            className="flex items-center justify-center gap-2 rounded-xl bg-primary px-3 py-2.5 text-sm text-primary-foreground hover:opacity-90"
          >
            <LogIn className="h-4 w-4" /> Log in
          </Link>
        )}
      </div>
    </aside>
  );
}